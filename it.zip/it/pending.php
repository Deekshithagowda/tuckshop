<php?
 include 'connection.php'
$query="select * from upload where location='pending'";
 $run= mysqli_query($connection,$query);
      
   
      
echo("

	<head>
		<title>File-upload</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/jquery.scrollgress.min.js"></script>
		<script src="js/jquery.scrolly.min.js"></script>
		<script src="js/jquery.slidertron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		
            
           
	</head>
	<body class="landing">

		
			<header id="header" class="alt skel-layers-fixed">
				<h1>Tuck Shop Presidency University</h1>
				<nav id="nav">
					<ul>
						
						<li>
							<a href="completed.html">Completed</a>
							
						</li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>
			</header>

		
			<section id="banner">
				<div class="inner">

                            <h2>PENDING</h2>

				</div>
			</section>

		
			
			
		
			
			
		
			<section id="three" class="wrapper style1">
				<div class="container">
					<header class="major">
						<h2>Document Queue</h2>
						
					</header>
					
					</div>
				
			</section>
			

	</body>
");
       while ($fetch=mysqli_fetch_row($run))
    {
    printf ("(%s)",$fetch[1]);
    }
      
      
      ?>