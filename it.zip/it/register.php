<?php
include 'connection.php';
    
    $name =$_POST["name"];
    $id=$_POST["id"];
    $email=$_POST["email"];
    $phno=$_POST["phno"];
    $password=$_POST["password"];
    $cpassword=$_POST["password"];

    if($password==$cpassword)
    {  
        $q1="insert into register (name,id,email,phno,password) values ('$name','$id','$email','$phno','$password')";
        $r1=mysqli_query($connection,$q1);
     
        if($r1)
        {
            session_start(); 
            header("location:upload.html");
            $_SESSION["id"]=$id;
            $_SESSION["set"]=TRUE;
        }
    }
    else
    {
        die("Error in regestring");
    }
?>