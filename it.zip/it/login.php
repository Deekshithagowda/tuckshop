<?php
    include 'connection.php';
    $id=$_POST['id'];
    $password=$_POST['password'];
    $query="select password from register where id='$id'";
    $run=mysqli_query($connection,$query)or die("Error");
    $fetch=mysqli_fetch_array($run);

    $query1="select role from register where id='$id'";
    $run1=mysqli_query($connection,$query1)or die('Error');
    $fetch1=mysqli_fetch_array($run1);
    
    if($fetch[0]==$password)
    {
        if($fetch1[0]=='user'){
            
        session_start();
            header("location:upload.html");
        $_SESSION["id"]=$id;
        $_SESSION["set"]=TRUE;
         }
        if($fetch1[0]=='admin'){
            session_start();
            header("location:pending.html");
        $_SESSION["id"]=$id;
        $_SESSION["set"]=TRUE;
    }
    }
    elseif($fetch[0]==NULL)
    {
        echo("<script> alert('User name not registred'); </script");
    }
    else
    {
        echo ("<script>alert('Incorrect password or username');</script>");
    }
?>