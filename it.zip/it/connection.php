<?php
$connection=mysqli_connect('localhost','root','','print');
if (!$connection)
{
    die("Connection error: ".mysqli_connect_error());
}
?>